export type ResourceObject = number;
