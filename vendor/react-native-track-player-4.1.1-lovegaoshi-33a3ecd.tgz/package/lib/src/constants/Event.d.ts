export declare enum Event {
    PlayerError = "player-error",
    /** Fired when the state of the player changes. */
    PlaybackState = "playback-state",
    /** Fired when a playback error occurs. */
    PlaybackError = "playback-error",
    /** (Android Only) Fired when animated volume completed changing. */
    PlaybackAnimatedVolumeChanged = "playback-animated-volume-changed",
    /** Fired after playback has paused due to the queue having reached the end. */
    PlaybackQueueEnded = "playback-queue-ended",
    /**
     * Fired when another track has become active or when there no longer is an
     * active track.
     *
     * @deprecated use `playback-active-track-changed` instead.
     **/
    PlaybackTrackChanged = "playback-track-changed",
    /**
     * Fired when another track has become active or when there no longer is an
     * active track.
     **/
    PlaybackActiveTrackChanged = "playback-active-track-changed",
    /**
     * Fired when the current track receives metadata encoded in. (e.g. ID3 tags,
     * Icy Metadata, Vorbis Comments or QuickTime metadata).
     * @deprecated use `AudioChapterMetadataReceived, AudioTimedMetadataReceived, AudioCommonMetadataReceived` instead.
     **/
    PlaybackMetadataReceived = "playback-metadata-received",
    /**
     * Fired when playback play when ready has changed.
     **/
    PlaybackPlayWhenReadyChanged = "playback-play-when-ready-changed",
    /**
     * Fired when playback progress has been updated.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#playbackprogressupdated
     **/
    PlaybackProgressUpdated = "playback-progress-updated",
    /**
     * Android media3 playback resumption. most likely require a
     * headless setup.
     */
    PlaybackResume = "playback-resume-android",
    /**
     * Fired when the user presses the play button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteplay
     **/
    RemotePlay = "remote-play",
    /**
     * Fired when the user presses the play/pause button.
     **/
    RemotePlayPause = "remote-play-pause",
    /**
     * Fired when the user presses the pause button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotepause
     **/
    RemotePause = "remote-pause",
    /**
     * Fired when the user presses the stop button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotestop
     **/
    RemoteStop = "remote-stop",
    /**
     * Fired when the user presses the next track button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotenext
     **/
    RemoteNext = "remote-next",
    /**
     * Fired when the user presses the previous track button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteprevious
     **/
    RemotePrevious = "remote-previous",
    /**
     * Fired when the user presses the jump forward button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotejumpforward
     **/
    RemoteJumpForward = "remote-jump-forward",
    /**
     * Fired when the user presses the jump backward button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotejumpbackward
     **/
    RemoteJumpBackward = "remote-jump-backward",
    /**
     * Fired when the user changes the position of the timeline.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteseek
     **/
    RemoteSeek = "remote-seek",
    /**
     * Fired when the user changes the rating for the track remotely.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotesetrating
     **/
    RemoteSetRating = "remote-set-rating",
    /**
     * Fired when the app needs to handle an audio interruption.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteduck
     **/
    RemoteDuck = "remote-duck",
    /**
     * (iOS only) Fired when the user presses the like button in the now playing
     * center.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotelike-ios-only
     **/
    RemoteLike = "remote-like",
    /**
     * (iOS only) Fired when the user presses the dislike button in the now playing
     * center.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotedislike-ios-only
     **/
    RemoteDislike = "remote-dislike",
    /** (iOS only) Fired when the user presses the bookmark button in the now
     * playing center.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remotebookmark-ios-only
     **/
    RemoteBookmark = "remote-bookmark",
    /**
     * (Android only) Fired when the user selects a track from an external device.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteplayid
     **/
    RemotePlayId = "remote-play-id",
    /**
     * (Android only) Fired when the user searches for a track (usually voice search).
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteplaysearch
     **/
    RemotePlaySearch = "remote-play-search",
    /**
     * (Android only) Fired when the user presses the skip button.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteskip
     **/
    RemoteSkip = "remote-skip",
    /**
     * (Android only) Fired when the user enters a browsable children in android auto.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteBrowse
     **/
    RemoteBrowse = "remote-browse",
    /**
     * (Android only) Fired when a custom action button is pressed.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#remoteCustomAction
     **/
    RemoteCustomAction = "remote-custom-action",
    /** (iOS only) Fired when chapter metadata is received.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#chaptermetadatareceived
     **/
    MetadataChapterReceived = "metadata-chapter-received",
    /**
     * Fired when metadata is received at a specific time in the audio.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#timedmetadatareceived
     **/
    MetadataTimedReceived = "metadata-timed-received",
    /**
     * Fired when common (static) metadata is received.
     * See https://doublesymmetry.github.io/react-native-track-player/docs/api/events#commonmetadatareceived
     **/
    MetadataCommonReceived = "metadata-common-received",
    /**
     * Fired when an android connector connects to MusicService.
     * typical controllers are media notification and Android Auto.
     **/
    connectorConnected = "android-controller-connected",
    /**
     * Fired when an android connector connects to MusicService.
     * typical controllers are media notification and Android Auto.
     **/
    connectorDisconnected = "android-controller-disconnected",
    /**
     * Fired when there is an fft update
     **/
    fftUpdate = "fft-updated"
}
